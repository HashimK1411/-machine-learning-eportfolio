# Module Learning Outcomes

1. Legal, social, ethical and professional issues
2. Dataset applicability and challenges
3. Applying and appraising ML techniques
4. Teamwork in virtual environments

Each section of this portfolio demonstrates how I met these outcomes.