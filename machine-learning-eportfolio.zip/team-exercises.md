# Team Exercises

## Meeting Notes
- Week 1: Kickoff and role assignment
- Week 2: Dataset selection and planning

## Contributions
- I contributed to data preprocessing and model evaluation.

## Outcomes
- Successfully trained and evaluated a classification model.