# About Me

Hi, I'm Hashim. I'm currently studying Artificial Intelligence and this portfolio reflects my work in the Machine Learning module.