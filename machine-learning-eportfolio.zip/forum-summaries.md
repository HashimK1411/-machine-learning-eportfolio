# Forum Summaries

## Week 1 Discussion
- Topic: Ethical implications of ML
- Summary: Discussed fairness and bias in algorithms.

## Week 2 Discussion
- Topic: Dataset challenges
- Summary: Explored issues with imbalanced datasets.