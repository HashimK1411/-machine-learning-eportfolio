# Welcome to My Machine Learning E-Portfolio

This portfolio showcases my learning journey, projects, and reflections for the Machine Learning module.